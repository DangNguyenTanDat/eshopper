<?php
include_once'./core/boot.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $producId = $_GET['id'];
    $produc = get_product($producId);
    include_once './view/_detail.php';

}