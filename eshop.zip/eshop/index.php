<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $produc = get_product($producId);
    include_once './view/_index.php';
}